<?php // compatibility
require_once( dirname( __FILE__ ) . '/joomla.xml.php' );
?>