<?php // no direct access
defined('_JEXEC') or die('Restricted access'); ?>
<div style="padding: 10px;">
	<div style="text-align:right">
		<a href="javascript: void window.close()">
			<?php echo JText::_('Close Window'); ?> <img src="<?php echo JURI::base() ?>components/com_mailto/assets/close-x.png" border="0" alt="" title="" /></a>
	</div>

	<div class="componentheading">
		<?php echo JText::_('EMAIL_SENT'); ?>
	</div>
</div>
