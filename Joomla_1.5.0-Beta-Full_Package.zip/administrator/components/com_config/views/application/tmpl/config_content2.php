<fieldset class="adminform">
	<legend><?php echo JText::_( 'Content Item Settings' ); ?></legend>
	<span class="note"><span class="editlinktip">
	<?php
		$tip = 'TIPTOC';
		echo mosToolTip( $tip, '', 280, 'tooltip.png', 'Table of Contents on multi-page items', 'index.php?option=com_plugins&client=site&task=editA&hidemainmenu=1&id=2' );
	?>
	</span></span>
	<table class="admintable" cellspacing="1">
		<tr>
			<td width="185" class="key">
				<?php echo JText::_( 'PDF Icon' ); ?>
			</td>
			<td>
				<?php echo $lists['hidePdf']; ?>
				<?php
					if (!is_writable( JPATH_SITE . '/media/' )) {
					   	$tip = 'TIPOPTIONMEDIA' ;
						echo mosToolTip( $tip );
					}
				?>
			</td>
		</tr>
		<tr>
			<td class="key">
				<?php echo JText::_( 'Print Icon' ); ?>
			</td>
			<td>
				<?php echo $lists['hidePrint']; ?>
			</td>
		</tr>
		<tr>
			<td class="key">
				<?php echo JText::_( 'Email Icon' ); ?>
			</td>
			<td>
				<?php echo $lists['hideEmail']; ?>
			</td>
		</tr>
		<tr>
			<td class="key">
				<span class="editlinktip">
				<?php
					$tip = 'TIPPRINTPDFEMAIL';
					echo mosToolTip( $tip, '', 280, 'tooltip.png', 'Icons' , '', 0 );
				?>
				</span>
			</td>
			<td>
				<?php echo $lists['icons']; ?>
			</td>
		</tr>
		<tr>
			<td class="key">
				<span class="editlinktip">
				<?php
					$tip = 'TIPIFSETTOSHOWHITS';
					echo mosToolTip( $tip, '', 280, 'tooltip.png', 'Hits', '', 0 );
				?>
				</span>
			</td>
			<td>
				<?php echo $lists['hits']; ?>
			</td>
		</tr>
		</table>




</fieldset>
