<fieldset class="adminform">
	<legend><?php echo JText::_( 'User Settings' ); ?></legend>
	
	<table class="admintable" cellspacing="1">
		<tbody>
		<tr>
			<td class="key">
				<span class="editlinktip">
				<?php
				$tip = 'TIPFRONTENDUSERPARAMS';
				echo mosToolTip( $tip, '', 280, 'tooltip.png', 'Frontend User Params', '', 0 );
				?>
				</span>
			</td>
			<td>
				<?php echo $lists['frontend_userparams']; ?>
			</td>
		</tr>
		</tbody>
	</table>
</fieldset>