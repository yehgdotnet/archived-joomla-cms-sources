<fieldset class="adminform">
	<legend><?php echo JText::_( 'FTP Settings' ); ?></legend>
	<table class="admintable" cellspacing="1">

		<tbody>
		<tr>
			<td width="185" class="key">
				<?php echo JText::_( 'Enable FTP' ); ?>
			</td>
			<td>
				<?php echo $lists['enable_ftp']; ?>
			</td>
		</tr>
		<tr>
			<td class="key">
				<?php echo JText::_( 'FTP Host' ); ?>
			</td>
			<td>
				<input class="text_area" type="text" name="ftp_host" size="25" value="<?php echo $row->ftp_host; ?>" />
			</td>
		</tr>
		<tr>
			<td class="key">
				<?php echo JText::_( 'FTP Port' ); ?>
			</td>
			<td>
				<input class="text_area" type="text" name="ftp_port" size="25" value="<?php echo $row->ftp_port; ?>" />
			</td>
		</tr>
		<tr>
			<td class="key">
				<?php echo JText::_( 'FTP Username' ); ?>
			</td>
			<td>
				<input class="text_area" type="text" name="ftp_user" size="25" value="<?php echo $row->ftp_user; ?>" />
			</td>
		</tr>
		<tr>
			<td class="key">
				<?php echo JText::_( 'FTP Password' ); ?>
			</td>
			<td>
				<input class="text_area" type="password" name="ftp_pass" size="25" value="<?php echo $row->ftp_pass; ?>" />
			</td>
		</tr>
		<tr>
			<td class="key">
				<?php echo JText::_( 'FTP Root' ); ?>
			</td>
			<td>
				<input class="text_area" type="text" name="ftp_root" size="50" value="<?php echo $row->ftp_root; ?>" />
			</td>
		</tr>
		</tbody>
	</table>
</fieldset>
