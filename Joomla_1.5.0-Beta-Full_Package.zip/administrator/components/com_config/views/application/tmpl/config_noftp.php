<fieldset class="adminform">
	<legend><?php echo JText::_( 'FTP Settings' ); ?></legend>
	<table class="admintable" cellspacing="1">

		<tbody>
		<tr>
			<td width="185" class="key">
				<?php echo JText::_( 'Enable FTP' ); ?>
			</td>
			<td>
				<?php echo JText::_( 'NOFTPONWIN' ); ?>
			</td>
		</tr>
		<tr>
		</tbody>
	</table>
</fieldset>
