<fieldset class="adminform">
	<legend><?php echo JText::_( 'Content Settings' ); ?></legend>
		<table class="admintable" cellspacing="1">
		<tr>
			<td class="key">
				<span class="editlinktip">
				<?php
				$tip = 'TIPLINKS';
				echo mosToolTip( $tip, '', 280, 'tooltip.png', 'Show UnAuthorized Links', '', 0 );
				?>
				</span>
			</td>
			<td>
				<?php echo $lists['shownoauth']; ?>
			</td>
		</tr>
		<tr>
			<td width="185" class="key">
				<span class="editlinktip">
				<?php
					$tip = 'TIPIFYESTITLECONTENTITEMS' ;
					echo mosToolTip( $tip, '', 280, 'tooltip.png',  'Linked Titles', '', 0 );
				?>
				</span>
			</td>
			<td>
				<?php echo $lists['link_titles']; ?>
			</td>
		</tr>
		<tr>
			<td class="key">
				<span class="editlinktip">
				<?php
					$tip = 'TIPIFSETTOSHOWREADMORELINK';
					echo mosToolTip( $tip, '', 280, 'tooltip.png', 'Read More Link', '', 0 );
				?>
				</span>
			</td>
			<td>
				<?php echo $lists['readmore']; ?>
			</td>
		</tr>
		<tr>
			<td class="key">
				<span class="editlinktip">
				<?php
					$tip = 'TIPIFSETTOSHOWVOTING';
					echo mosToolTip( $tip, '', 280, 'tooltip.png', 'Item Rating/Voting', '', 0 );
				?>
				</span>
			</td>
			<td>
				<?php echo $lists['vote']; ?>
			</td>
		</tr>
		<tr>
			<td class="key">
				<span class="editlinktip">
				<?php
					$tip = 'TIPIFSETTOSHOWAUTHOR';
					echo mosToolTip( $tip, '', 280, 'tooltip.png', 'Author Names', '', 0 );
				?>
				</span>
			</td>
			<td>
				<?php echo $lists['hideAuthor']; ?>
			</td>
		</tr>
		<tr>
			<td class="key">
				<span class="editlinktip">
				<?php
					$tip = 'TIPIFSETTOSHOWDATETIMECREATED';
					echo mosToolTip( $tip, '', 280, 'tooltip.png', 'Created Date and Time', '', 0 );
				?>
				</span>
			</td>
			<td>
				<?php echo $lists['hideCreateDate']; ?>
			</td>
		</tr>
		<tr>
			<td class="key">
				<span class="editlinktip">
				<?php
					$tip = 'TIPIFSETTOSHOWDATETIMEMODIFIED';
					echo mosToolTip( $tip, '', 280, 'tooltip.png', 'Modified Date and Time', '', 0 );
				?>
				</span>
			</td>
			<td>
				<?php echo $lists['hideModifyDate']; ?>
			</td>
		</tr>
	</table>
</fieldset>