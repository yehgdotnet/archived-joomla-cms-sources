<fieldset class="adminform">
	<legend><?php echo JText::_( 'Statistics Settings' ); ?></legend>
	<table class="admintable" cellspacing="1">

		<tbody>
		<tr>
			<td widt="185" class="key">
			<span class="editlinktip">
				<?php
					echo mosToolTip( 'TIPENABLEDISABLESTATS', '', 280, 'tooltip.png', 'Statistics', '', 0 );
				?>
				</span>
			</td>
			<td>
				<?php echo $lists['enable_stats']; ?>
			</td>
		</tr>
		<tr>
			<td class="key">
				<?php echo JText::_( 'Log Content Hits by Date' ); ?>
			</td>
			<td>
				<?php echo $lists['log_items']; ?>
				<span class="error">
				<?php
					$warn = JText::_( 'TIPLARGEAMOUNTSOFDATA', true );
					echo ConfigApplicationView::WarningIcon( $warn );
				?>
				</span>
			</td>
		</tr>
		<tr>
			<td class="key">
				<?php echo JText::_( 'Log Search Strings' ); ?>
			</td>
			<td>
				<?php echo $lists['log_searches']; ?>
			</td>
		</tr>
		</tbody>
	</table>
</fieldset>
