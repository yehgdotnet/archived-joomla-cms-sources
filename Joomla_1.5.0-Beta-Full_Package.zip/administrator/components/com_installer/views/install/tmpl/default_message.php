<fieldset title="<?php echo $this->state->message; ?>">
	<legend><?php echo $this->state->message; ?></legend>
	<table class="adminform">
		<tbody>
			<tr>
				<td><strong><?php echo $this->install->description; ?></strong></td>
			</tr>
			<tr>
				<td><?php echo $this->install->message; ?></td>
			</tr>
		</tbody>
	</table>
</fieldset>
