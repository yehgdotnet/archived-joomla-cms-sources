<table class="adminform">
	<tbody>
		<tr>
			<td><?php echo $this->state->message; ?></td>
		</tr>
	</tbody>
</table>
