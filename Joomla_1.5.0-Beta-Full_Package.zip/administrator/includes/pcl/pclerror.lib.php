<?php // compatibility
require_once( dirname(__FILE__)  .'/../../../libraries/pcl/pclerror.lib.php' );
?>