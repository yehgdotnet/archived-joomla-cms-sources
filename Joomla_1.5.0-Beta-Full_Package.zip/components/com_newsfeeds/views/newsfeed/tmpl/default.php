<div style="direction: <?php echo $this->newsfeed->rtl ? 'rtl' :'ltr'; ?>; text-align: <?php echo $this->newsfeed->rtl ? 'right' :'left'; ?>">
<table width="100%" class="contentpane<?php echo $this->params->get( 'pageclass_sfx' ); ?>">
<?php if ( $this->params->get( 'header' ) ) : ?>
<tr>
	<td class="componentheading<?php echo $this->params->get( 'pageclass_sfx' ); ?>" colspan="2">
		<?php echo $this->params->get( 'header' ); ?>
	</td>
</tr>
<?php endif; ?>
<tr>
	<td class="contentheading<?php echo $this->params->get( 'pageclass_sfx' ); ?>">
		<a href="<?php echo ampReplace( $this->newsfeed->channel['link'] ); ?>" target="_blank">
			<?php echo str_replace('&apos;', "'", $this->newsfeed->channel['title']); ?>
		</a>
	</td>
</tr>
<?php if ( $this->params->get( 'feed_descr' ) ) : ?>
<tr>
	<td>
		<?php echo str_replace('&apos;', "'", $this->newsfeed->channel['description']); ?>
		<br />
		<br />
	</td>
</tr>
<?php endif; ?>
<?php if ( isset($this->newsfeed->image['url']) && isset($this->newsfeed->image['title']) && $this->params->get( 'feed_image' ) ) : ?>
<tr>
	<td>
		<img src="<?php echo $this->newsfeed->image['url']; ?>" alt="<?php echo $this->newsfeed->image['title']; ?>" />
	</td>
</tr>
<?php endif; ?>
<tr>
	<td>
		<ul>
		<?php foreach ( $this->newsfeed->items as $item ) :  ?>
			<li>
			<?php if ( !is_null( $item['link'] ) ) : ?>
				<a href="<?php echo ampReplace( $item['link'] ); ?>" target="_blank">
					<?php echo $item['title']; ?>
				</a>
			<?php endif; ?>
			<?php if ( $this->params->get( 'item_descr' ) && isset($item['description'])) : ?>
				<br />
				<?php $text = $this->limitText($item['description'], $this->params->get( 'word_count' ));
					echo str_replace('&apos;', "'", $text);
				?>
				<br />
				<br />
			<?php endif; ?>
			</li>
		<?php endforeach; ?>
		</ul>
	</td>
</tr>
</table>
</div>