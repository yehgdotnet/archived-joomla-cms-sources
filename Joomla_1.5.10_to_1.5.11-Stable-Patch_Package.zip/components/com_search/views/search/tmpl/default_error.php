<?php defined('_JEXEC') or die('Restricted access'); ?>

<table class="searchintro<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>">
	<tr>
		<td colspan="3" >
			<?php echo $this->escape($this->error); ?>
		</td>
	</tr>
</table>
