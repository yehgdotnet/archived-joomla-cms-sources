<?php
/**
 * @version		$Id: controller.php 16401 2010-04-24 00:32:14Z eddieajau $
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access.
defined('_JEXEC') or die;

jimport('joomla.application.component.controller');

/**
 * Messages master display controller.
 *
 * @package		Joomla.Administrator
 * @subpackage	com_messages
 * @since		1.6
 */
class MessagesController extends JController
{
	/**
	 * Method to display a view.
	 */
	public function display()
	{
		require_once JPATH_COMPONENT.'/helpers/messages.php';

		parent::display();

		// Load the submenu.
		//MessagesHelper::addSubmenu(JRequest::getWord('view', 'messages'));
	}
}