<?php
/**
 * @version		$Id: controller.php 16398 2010-04-24 00:28:26Z eddieajau $
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controller');

/**
 * Component Controller
 *
 * @package		Joomla.Administrator
 * @subpackage	com_content
 */
class ContactController extends JController
{
	/**
	 * @var		string	The default view.
	 * @since	1.6
	 */
	protected $default_view = 'contacts';

	/**
	 * Display the view
	 */
	function display()
	{
		require_once JPATH_COMPONENT.'/helpers/contact.php';

		parent::display();

		// Load the submenu.
		ContactHelper::addSubmenu(JRequest::getWord('view', 'contacts'));
	}
}
